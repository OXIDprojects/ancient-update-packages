UPDATE `oxshops` SET `OXVERSION` = '4.5.7-';

REPLACE INTO `oxconfig` VALUES('mhjf24905a5b49c8d60aa31087b9797f', 'oxbaseshop', '', 'blShowRememberMe', 'bool', 0x07);

UPDATE `oxshops` SET `OXVERSION` = '4.5.7';
