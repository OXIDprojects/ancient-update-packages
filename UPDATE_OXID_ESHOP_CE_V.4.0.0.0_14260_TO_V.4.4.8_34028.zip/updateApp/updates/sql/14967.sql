# openid  field for oxuser table
ALTER TABLE `oxuser` ADD `OXISOPENID` TINYINT(1) NOT NULL DEFAULT '0';
UPDATE `oxshops` SET `OXVERSION` = '4.0.1.0';

# restoring accounts without password
UPDATE oxuser SET oxpasssalt = '', oxpassword = '' WHERE oxpassword != '' AND oxpasssalt != '' AND UNHEX( oxpasssalt ) IS NOT NULL AND oxpassword = MD5( CONCAT( '', UNHEX( oxpasssalt ) ) );