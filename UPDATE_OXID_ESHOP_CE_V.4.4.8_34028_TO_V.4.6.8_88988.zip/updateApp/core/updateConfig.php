<?php
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2011
 * @version OXID eShop CE
 */

/**
 * class for keeping and retrieving update configuration values
 */
class updateConfig
{
    /**
     * get path to sql updates
     * @return string
     */
    public function getSqlPath()
    {
        return realpath(dirname(__FILE__).'/../updates/sql/');
    }

    /**
     * get path to sql updates
     * @return string
     */
    public function getPhpPath()
    {
        return realpath(dirname(__FILE__).'/../updates/php/');
    }

    /**
     * list all posible revisions, sorted ascending
     *
     * @return array
     */
    public function getAvailableRevisions()
    {
        $aRet = array();
        $aPhp = glob($this->getPhpPath().'/*.php');
        $aSql = glob($this->getSqlPath().'/*.sql');
        if (!is_array($aPhp)) {
            $aPhp = array();
        }
        if (!is_array($aSql)) {
            $aSql = array();
        }
        foreach (array_merge($aPhp, $aSql) as $sFile) {
            if (preg_match('/^(.*\/)?([0-9]+)\.(php|sql)$/i', $sFile, $m)) {
                $aRet[] = (int) $m[2];
            }
        }
        $aRet = array_unique($aRet);
        sort($aRet, SORT_NUMERIC);
        return $aRet;
    }


    /**
     * Returns shop build revision number or false on read error.
     *
     * @return int
     */
    public function getStartRevision()
    {
        // update from start of current archived update files
        return 0;
    }
}
