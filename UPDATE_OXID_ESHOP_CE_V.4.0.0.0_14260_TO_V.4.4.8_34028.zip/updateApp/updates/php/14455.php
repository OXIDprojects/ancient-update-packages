<?php
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2011
 * @version OXID eShop CE
 */


/**
 * update class for rev. 14455
 */
class update_14455 extends updateBase
{
    protected $_iRecPerTick = 500;

    /**
     * Returns safe password salt value
     *
     * @return string
     */
    public function getSaltVal( $sShopId )
    {
        $sQ  = "select HEX( DECODE( oxvarvalue, '".$this->getConfig()->getConfigParam( 'sConfigKey' )."') ) as oxvarvalue from oxconfig where oxshopid = '$sShopId' and oxvarname = 'sPasswdSalt'";
        return oxDb::getDb(true)->getOne( $sQ );
    }


    /**
     * Inserting salts for all users (which has not salts yet) according to shop id
     *
     * @return string
     */
    public function setDefaultUserSalt()
    {
        $oDb = oxDb::getDb(true);
        $iUsersCnt = $oDb->getOne( "select count(oxuser.oxid) from oxshops left join oxuser on oxuser.oxshopid=oxshops.oxid where oxuser.oxusername is not null and oxuser.oxpasssalt = ''" );

        // to avoid timeouts updating X entries per tick
        $iQty  = (int) ( $this->_iRecPerTick > $iUsersCnt ? $iUsersCnt : $this->_iRecPerTick );

        // selecting shop list
        $sShopId = $oDb->getOne( 'select oxshops.oxid from oxshops left join oxuser on oxuser.oxshopid=oxshops.oxid where oxuser.oxusername is not null and oxuser.oxpasssalt = ""' );
        if ( $sShopId ) {
            $sShopSalt = $this->getSaltVal( $sShopId );
            $sQ = "update oxuser set oxuser.oxpasssalt = '{$sShopSalt}' where oxuser.oxpasssalt = '' and oxuser.oxshopid = '{$sShopId}' limit {$iQty}";
            $oDb->execute( $sQ );
        }

        if ( $iUsersCnt ) {
            return 'setDefaultUserSalt';
        } else {
            return 'updatePlainUserPasswords';
        }
    }

    /**
     * Updates user passwords. Returns name of next action to execute
     *
     * @return string
     */
    public function updatePlainUserPasswords()
    {
        $oDb = oxDb::getDb(true);
        $iUsersCnt = $oDb->getOne( "select count(*) from oxuser where LENGTH( oxpassword ) < 32 and oxpassword not like 'ox\_%' and oxuser.oxpasssalt != '' " );

        // to avoid timeouts updating X entries per tick
        $iQty  = (int) ( $this->_iRecPerTick > $iUsersCnt ? $iUsersCnt : $this->_iRecPerTick );

        $sQ = "update oxuser set oxpassword = MD5( CONCAT( oxuser.oxpassword, UNHEX( oxuser.oxpasssalt ) ) ) where LENGTH( oxuser.oxpassword ) < 32 and oxuser.oxpassword not like 'ox\_%' and oxuser.oxpasssalt != '' limit {$iQty}";
        $oDb->execute( $sQ );

        if ( $iUsersCnt ) {
            // stil something todo
            return 'updatePlainUserPasswords';
        } else {
            // last tick
            return 'updateDecodableUserPasswords';
        }
    }

    /**
     * Updates user passwords. Returns name of next action to execute
     *
     * @return string
     */
    public function updateDecodableUserPasswords()
    {
        $myConfig = $this->getConfig();
        $oDb = oxDb::getDb(true);
        $iUsersCnt = $oDb->getOne( "select count(*) from oxuser where LENGTH( oxpassword ) < 32 and oxpassword like 'ox\_%' and oxuser.oxpasssalt != ''" );

        // to avoid timeouts updating X entries per tick
        $iQty  = (int) ( $this->_iRecPerTick > $iUsersCnt ? $iUsersCnt : $this->_iRecPerTick );

        $sQ = "select oxid, oxpassword from oxuser where LENGTH( oxpassword ) < 32 and oxpassword like 'ox\_%' and oxuser.oxpasssalt != '' limit 0, {$iQty}";
        $aData = $oDb->getAll( $sQ );

        if ( is_array( $aData ) && count( $aData ) ) {
            foreach ( $aData as $aUserData ) {
                $sPlainPass = oxUtils::getInstance()->strRem( $aUserData['oxpassword'], $myConfig->getConfigParam('sConfigKey') );
                $sQ = "update oxuser set oxpassword = MD5( CONCAT( '{$sPlainPass}', UNHEX( oxpasssalt ) ) ) where oxid = '{$aUserData['oxid']}'";
                $oDb->execute( $sQ );
            }
        }

        if ( $iUsersCnt ) {
            // stil something todo
            return 'updateDecodableUserPasswords';
        } else {
            // last tick
            return 'updateSeo';//'testEncodedPasswords';
        }
    }

    /**
     * Updates actual SEO table entries
     */
    public function updateSeo()
    {
        $myConfig = $this->getConfig();
        $oDb = oxDb::getDb(true);

        // selecting shop list
        $aShopIds = $oDb->getAll( 'select oxid from oxshops' );
        if ( is_array( $aShopIds ) && count( $aShopIds ) ) {
            foreach ( $aShopIds as $aShopData ) {
                $aLangArray = $myConfig->getShopConfVar( 'aLanguages', $aShopData['oxid'] );
                $aLangIds = array_keys( $aLangArray );
                foreach ( $aLangIds as $iLangId => $sLangCode ) {
                    // updating seo entries
                    $sQ = "update oxseo set oxident = MD5( LOWER(  CONCAT( '{$sLangCode}/', oxseourl ) ) ) where oxlang = '{$iLangId}' ";
                    $oDb->execute( $sQ );
                }
            }
        }
        return '';
    }

    public function updateSql($iInStepCounter)
    {
        $sRet = parent::updateSql($iInStepCounter);
        if ($sRet == '') {
            return 'setDefaultUserSalt';
        }
        return $sRet;
    }

}

