<?php
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2011
 * @version OXID eShop CE
 */


/**
 * update class for rev. 14455
 */
class update_44222 extends updateBase
{

    /**
     * default action, used in start update
     *
     * @var string
     */
    protected $_sDefaultAction = 'setOrderCounters';

    /**
     * Inserts counter values from ox orders table
     *
     * @return string
     */
    public function setOrderCounters()
    {
        $oDb       = oxDb::getDb( true );
        $oConfig  = $this->getConfig();

        $oDb->execute("
            CREATE TABLE  `oxcounters` (
                  `OXIDENT` CHAR( 32 ) NOT NULL ,
                  `OXCOUNT` INT NOT NULL ,
                  PRIMARY KEY (  `OXIDENT` )
            ) ENGINE = InnoDB;");

        if ( $oConfig->getConfigParam( 'blSeparateNumbering' ) ){
            $oDb->Execute("
                insert into `oxcounters` ( `oxident`, `oxcount` )
                select CONCAT( 'oxOrder_', `oxshopid` ), MAX(`oxordernr`) from `oxorder` group by `oxshopid`"
            );
        } else {
            $oDb->Execute("
                insert into `oxcounters` ( `oxident`, `oxcount` )
                select 'oxOrder', MAX(`oxordernr`) from `oxorder`"
            );
        }

        return 'addDownloadsConfigs';
    }

    /**
     * Inserts sDownloadsDir parameter and creates dir
     *
     * @return string
     */
    public function addDownloadsConfigs()
    {

        $oDb = oxDb::getDb( true );
        $sCode = $this->getConfig()->getConfigParam( 'sConfigKey' );
        $aConfigParams = array( 'sDownloadsDir' => 'out/downloads',
                                'iLinkExpirationTime' => '168',
                                'iDownloadExpirationTime' => '24',
                                'iMaxDownloadsCountUnregistered' => '1',
                                'iMaxDownloadsCount' => '0' );

        foreach ( $aConfigParams as $sName => $sValue ) {
            // inserting value
            $sSql = "INSERT INTO `oxconfig` (`OXID`, `OXSHOPID`, `OXMODULE`, `OXVARNAME`, `OXVARTYPE`, `OXVARVALUE`)
                SELECT md5( concat( RAND(), '{$sName}', oxshops.oxid, oxshops.oxurl )), oxshops.oxid, '', '{$sName}', 'str', ENCODE( '{$sValue}' , '{$sCode}' ) FROM oxshops";
            $oDb->execute($sSql);
        }

        // creating dir
        $sPath = $this->getConfig()->getOutDir() . 'downloads';
        if ( !is_dir( $sPath ) ) {
            mkdir( $sPath, 0755 );
        }

        return 'addDownloadPageSeoUrl';
    }

    /**
     * Inserts sDownloadsDir parameter and creates dir
     *
     * @return string
     */
    public function addDownloadPageSeoUrl()
    {
        $oDb = oxDb::getDb(true);

        $aStaticUrl = array('oxseo__oxstdurl' => 'index.php?cl=download' );

        $aShopIds = $oDb->getAll("select `oxid` from `oxshops` order by `oxid`");

        if ( is_array( $aShopIds ) && count( $aShopIds ) ) {

            foreach ( $aShopIds as $aShopData ) {

                //getting shop lanuages
                $aLangs = $this->getConfig()->getShopConfVar( 'aLanguages', $aShopData['oxid'] );
                foreach ( $aLangs as $sLangId => $aLangVal ){
                    $aStaticUrl['oxseo__oxseourl'][] =  $sLangId . '/download/';
                }

                oxSeoEncoder::getInstance()->encodeStaticUrls( $aStaticUrl , $aShopData['oxid'], 0 );
            }
        }

        return 'updateSql';
    }

}
