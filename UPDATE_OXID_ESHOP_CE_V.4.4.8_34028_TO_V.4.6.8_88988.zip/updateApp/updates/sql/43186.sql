INSERT INTO `oxconfig` VALUES('mhjf24905a5b49c8d60aa31087b97971', 'oxbaseshop', '', 'blEnableSeoCache', 'bool', 0x07);

UPDATE `oxshops` SET `OXVERSION` = '4.5.10';