# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.3.2';