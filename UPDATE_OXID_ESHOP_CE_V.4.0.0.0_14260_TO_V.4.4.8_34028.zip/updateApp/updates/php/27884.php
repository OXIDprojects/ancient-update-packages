<?php 
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2011
 * @version OXID eShop CE
 */

/**
 * update class for rev. 27884
 */
class update_27884 extends updateBase
{
    /**
     * default action, used in start update
     *
     * @var string
     */
    protected $_sDefaultAction = 'updateTSIds';

    /**
     * Inserting salts for all users (which has not salts yet) according to shop id
     *
     * @return string
     */
    public function updateTSIds()
    {
        $myConfig = oxConfig::getInstance();
        $aShops = oxDb::getDb(true)->getAll('select oxid from oxshops');
        foreach ($aShops as $aShop) {
            $iShopId = $aShop['oxid'];
            $aRet = $myConfig->getShopConfVar( 'iShopID_TrustedShops', $iShopId );
            if (is_array($aRet)) {
                foreach ($aRet as $sKey => $sCert) {
                    if ( $sCert ) {
                        $oResults = $this->checkCertificate($sCert);
                        if ( $oResults && ($oResults->stateEnum == "PRODUCTION" || $oResults->stateEnum == "TEST" || $oResults->stateEnum == "INTEGRATION" )) {
                            $aTsType[$sKey] = $oResults->typeEnum;
                            $myConfig->saveShopConfVar( "bool", 'tsSealActive', true, $iShopId );
                            $myConfig->saveShopConfVar( "aarr", 'tsSealType', $aTsType, $iShopId );
                        } else {
                            $oUI = $this->_getProcess()->getUI();
                            $oInfo = $oUI->createTextNotification();
                                $oInfo->setText("Trusted Shops Id '$sCert' is not valid. Please enter valid Trusted Shops Id after update in Admin->eCommerce Services->Seal of Quality->Trusted Shops.");
                            $oUI->addErrorForUser($oInfo);
                        }
                    }
                }

            }
        }

        return 'updateSql';
    }

    /**
     * Executes TS certificate check
     *
     * @param integer $iTrustedShopId Trusted shop Id
     * @param bool    $blTsTestMode   if test mode is on
     *
     * @return object
     */
    public function checkCertificate( $iTrustedShopId, $blTsTestMode = false )
    {
        if ( $iTrustedShopId ) {
            try {
                if ( $blTsTestMode ) {
                    $sSoapUrl = 'https://qa.trustedshops.de/ts/services/TsProtection?wsdl';
                } else {
                    $sSoapUrl = 'https://www.trustedshops.de/ts/services/TsProtection?wsdl';
                }
                $sFunction = 'checkCertificate';
                $aValues['tsId']    = $iTrustedShopId;
                $oSoap = new SoapClient($sSoapUrl);
                $aResults = $oSoap->{$sFunction}($aValues['tsId']);
                if ( isset($aResults) ) {
                    return $aResults;
                }
            } catch( Exception $eException ) {
                return false;
            }
        }
        return null;

    }
}