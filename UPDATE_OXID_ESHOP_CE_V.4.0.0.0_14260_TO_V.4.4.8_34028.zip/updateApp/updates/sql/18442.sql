# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.1.2-';

# adding additional index to 'oxobject2article' table
ALTER TABLE `oxobject2article` ADD INDEX ( `OXOBJECTID` );

# updating shop version
UPDATE `oxshops` SET `OXVERSION` = '4.1.2';