<?php
/**
 *    This file is part of OXID eShop Community Edition.
 *
 *    OXID eShop Community Edition is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    OXID eShop Community Edition is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with OXID eShop Community Edition.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.oxid-esales.com
 * @package updateApp
 * @copyright (C) OXID eSales AG 2003-2011
 * @version OXID eShop CE
 */

    set_time_limit(0);
    set_include_path(get_include_path() . PATH_SEPARATOR . dirname(__FILE__).'/../../');

    require_once dirname(__FILE__).'/../../core/initshop.php';

    require_once dirname(__FILE__).'/../../core/updateProcess.php';
    require_once dirname(__FILE__).'/../../ui/http.php';

?><form id="mainform" onsubmit="callUpdate(this); return false;">
<?php

    $oUi = new uiHttp();
    $oProcess = new updateProcess($oUi);
    if ($oProcess->runStep()) {
        if ($oUi->getConfirmStatus()) {
            ?><input type="submit" style="margin-left: 30px;margin-top:40px;" value="Continue" /><?php
        } else {
            ?><div id="gonext" style="display:none;">go!</div><?php
        }
    } else {
        echo "<h2>update finished</h2>";
    }
    session_write_close();
?>
</form>
<div id="loginfo" style="display:none;"><?php echo $oUi->getLogText(); ?></div>
<!-- end of updater data (8f459dac0265) -->