# password salt field for oxuser table
ALTER TABLE `oxuser` ADD `OXPASSSALT` CHAR( 128 ) NOT NULL ;

# updating shop version to final version after the full update
UPDATE `oxshops` SET `OXVERSION` = '4.0.0.2';
